#include "WindowMessageHandler.h"
#include "CanvasTools.h"

// Must Initialize Static Singleton Instance
UWindowMessageHandler* UWindowMessageHandler::Instance = nullptr;

// Sets default values for this component's properties
UWindowMessageHandler::UWindowMessageHandler()
{
    UWindowMessageHandler::Instance = this;
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	this->PrimaryComponentTick.bCanEverTick = false;
}
