#include "CanvasTools.h"
#include "WindowMessageHandler.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Actor.h"

#ifdef __EMSCRIPTEN__
#define PLATFORM_HTML5_BROWSER 1
#include <emscripten/emscripten.h>
#include <emscripten/html5.h>
#include <cwchar>
#else
#define EM_ASM(x)
#define EM_ASM_(...)
#define EM_ASM_ARGS(...)
#define EMSCRIPTEN_KEEPALIVE
#endif

/* ************************ */
/* Toolkit Plugin Functions */
/* ************************ */

UCanvasTools::UCanvasTools(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
    // DEBUG: UE_LOG(LogTemp, Warning, TEXT("WTF 2: Some warning message") );
    // DEBUG: GEngine->AddOnScreenDebugMessage(-1, 60.0f, FColor::White, TEXT("This message will appear on the screen!"));
}

void UCanvasTools::LoadScene(FString scene)
{
    UWorld* world = nullptr;
    // ..
    // TODO: Better Way To Get Current World
    // ..
    if (GEngine)
    {
        TArray<APlayerController*> Players;
        GEngine->GetAllLocalPlayerControllers(Players);
        if (Players.Num())
        {
            world = Players[0]->GetWorld();
        }
    }
    if (world != nullptr)
    {
        FName level = FName(*scene);
        UGameplayStatics::OpenLevel(world, level, TRAVEL_Absolute);
    }
    else
    {
        UCanvasTools::LogError("Load scene failed to locate default world conext");
    }
}

void UCanvasTools::LogMessage(FString message, bool UE_Logging)
{
#ifdef PLATFORM_HTML5_BROWSER
    if (UE_Logging == true)
    {
        UE_LOG(LogTemp, Display, TEXT("%s"), *message);
    }
    else
    {
        EM_ASM_ARGS(
        {
            
            var str = UTF8ToString($0,$1);
            console.log(str);
            
        }, TCHAR_TO_ANSI(*message), message.Len());
    }
#else
    UE_LOG(LogTemp, Display, TEXT("%s"), *message);
#endif
}


void UCanvasTools::LogWarning(FString message, bool UE_Logging)
{
#ifdef PLATFORM_HTML5_BROWSER
    if (UE_Logging == true)
    {
        UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
    }
    else
    {
        EM_ASM_ARGS(
        {
            
            var str = UTF8ToString($0,$1);
            console.warn(str);
            
        }, TCHAR_TO_ANSI(*message), message.Len());
    }
#else
    UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
#endif
}

void UCanvasTools::LogError(FString message, bool UE_Logging)
{
#ifdef PLATFORM_HTML5_BROWSER
    if (UE_Logging == true)
    {
        UE_LOG(LogTemp, Error, TEXT("%s"), *message);
    }
    else
    {
        EM_ASM_ARGS(
        {
            
            var str = UTF8ToString($0,$1);
            console.error(str);
            
        }, TCHAR_TO_ANSI(*message), message.Len());
    }
#else
    UE_LOG(LogTemp, Error, TEXT("%s"), *message);
#endif
}

void UCanvasTools::PrintToScreen(FString message, int key, float timeout, FColor color)
{
    if (GEngine) GEngine->AddOnScreenDebugMessage(key, timeout, color, message);
}

void UCanvasTools::PostWindowMessage(FString command, FString param1, FString param2, FString param3, FString param4, FString param5, FString param6, FString param7, FString param8, FString sourceKey, FString targetOrigin, bool localWindow)
{
    FString message = FString::Printf(TEXT("{ source:'%s', command:'%s', param1:'%s', param2:'%s', param3:'%s', param4:'%s', param5:'%s', param6:'%s', param7:'%s', param8:'%s' }"), *sourceKey, *command, *param1, *param2, *param3, *param4, *param5, *param6, *param7, *param8);
    
    #ifdef PLATFORM_HTML5_BROWSER
        if (localWindow == true)
        {
            EM_ASM_ARGS(
            {
                
                var str = UTF8ToString($0,$1);
                var origin = UTF8ToString($2,$3);
                window.postMessage(str, origin);
                
            }, TCHAR_TO_ANSI(*message), message.Len(), TCHAR_TO_ANSI(*targetOrigin), targetOrigin.Len());
        }
        else
        {
            EM_ASM_ARGS(
            {
                
                var str = UTF8ToString($0,$1);
                var origin = UTF8ToString($2,$3);
                if (window.top) window.top.postMessage(str, origin);
            }, TCHAR_TO_ANSI(*message), message.Len(), TCHAR_TO_ANSI(*targetOrigin), targetOrigin.Len());
        }
    #else
        UE_LOG(LogTemp, Warning, TEXT("Post Window Message: %s"), *message);
    #endif
}

void UCanvasTools::ExecuteConsoleCommand(FString command)
{
    if (GEngine)
    {
        TArray<APlayerController*> Players;
        GEngine->GetAllLocalPlayerControllers(Players);
        if (Players.Num())
        {
            Players[0]->ConsoleCommand(command);
        }
    }
}

void UCanvasTools::BroadcastWindowMessageEvent(FString command, FString param1, FString param2, FString param3, FString param4, FString param5, FString param6, FString param7, FString param8)
{
    if (UWindowMessageHandler::Instance != nullptr)
    {
        UWindowMessageHandler::Instance->OnWindowMessage.Broadcast(command, param1, param2, param3, param4, param5, param6, param7, param8);
    }
}

/* ************************ */
/* Browser Module Functions */
/* ************************ */

#ifdef PLATFORM_HTML5_BROWSER
extern "C" void EMSCRIPTEN_KEEPALIVE LoadScene0(char* level)
{
    FString inputString(level);         // Note: This converts the char* level from JavaScript to a UE4 FString
    UCanvasTools::LoadScene(inputString);
}

extern "C" void EMSCRIPTEN_KEEPALIVE PrintToScreen0(char* message, int key, float timeout, char* hexcolor)
{
    FString inputString(message);       // Note: This converts the char* message from JavaScript to a UE4 FString
    FString inputHexColor(hexcolor);    // Note: This converts the char* hexcolor from JavaScript to a UE4 FString
    UCanvasTools::PrintToScreen(inputString, key, timeout, FColor::FromHex(inputHexColor));
}

extern "C" void EMSCRIPTEN_KEEPALIVE ExecuteConsoleCommand0(char* command)
{
    FString inputString(command);         // Note: This converts the char* command from JavaScript to a UE4 FString
    UCanvasTools::ExecuteConsoleCommand(inputString);
}

extern "C" void EMSCRIPTEN_KEEPALIVE DispatchWindowMessage0(char* command, char* param1, char* param2, char* param3, char* param4, char* param5, char* param6, char* param7, char* param8)
{
    FString inputString(command);       // Note: This converts the char* command from JavaScript to a UE4 FString
    FString paramString1(param1);       // Note: This converts the char* param1 from JavaScript to a UE4 FString
    FString paramString2(param2);       // Note: This converts the char* param2 from JavaScript to a UE4 FString
    FString paramString3(param3);       // Note: This converts the char* param3 from JavaScript to a UE4 FString
    FString paramString4(param4);       // Note: This converts the char* param4 from JavaScript to a UE4 FString
    FString paramString5(param5);       // Note: This converts the char* param5 from JavaScript to a UE4 FString
    FString paramString6(param6);       // Note: This converts the char* param6 from JavaScript to a UE4 FString
    FString paramString7(param7);       // Note: This converts the char* param7 from JavaScript to a UE4 FString
    FString paramString8(param8);       // Note: This converts the char* param8 from JavaScript to a UE4 FString
    UCanvasTools::BroadcastWindowMessageEvent(inputString, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8);
}
#endif
