#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "WindowMessageHandler.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_NineParams(FWindowMessageDelegate_OnWindowMessage, FString, command, FString, param1, FString, param2, FString, param3, FString, param4, FString, param5, FString, param6, FString, param7, FString, param8);

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent), Category = "Canvas Tools" )
class HTMLCANVASTOOLS_API UWindowMessageHandler : public UActorComponent
{
	GENERATED_BODY()
    
public:
	UWindowMessageHandler();
    static UWindowMessageHandler* Instance;

    UPROPERTY(BlueprintAssignable, Category = "Canvas Tools")
    FWindowMessageDelegate_OnWindowMessage OnWindowMessage;
};
